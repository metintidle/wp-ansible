# IT&T WebP Compressor

Standalone WordPress plugin extracted from [wp-itt-toolbox](../wp-itt-toolbox/) image processing. Converts uploads to WebP on the server using **CLI tools only** — PHP never loads full image bitmaps into memory.

Replaces legacy **plus-webp** on Ohara / IT&T WordPress hosts.

## What gets saved on upload

**One WebP replaces the full original and `-scaled` copy. Normal WP thumbnails are still created.**

| Before (default WP) | With this plugin |
|---------------------|------------------|
| `photo.jpg` (4000×3000) | *(deleted — never written)* |
| `photo-scaled.jpg` (2560×…) | *(blocked)* |
| — | `photo.webp` (max 2560px, compressed) |
| `photo-300x200.jpg`, etc. | `photo-300x200.webp`, etc. *(WP generates as usual)* |

Flow:

1. **Resize (if over max dimension)** — netpbm only: decode → `pamscale -filter=lanczos` (or `pnmscale`) → encode, then `cwebp`
2. **Convert in place** — `cwebp -low_memory` replaces the upload temp file; saved as `.webp` only
3. **No `-scaled` duplicate** — `big_image_size_threshold` is disabled; a metadata hook deletes any `-scaled` / backup original WP might still create
4. **Quality** — choose a strategy: **Fixed** (one pass at the set quality), **Content-aware** (netpbm pixel sampling nudges quality per image), or **SSIM target** (binary-searches the lowest quality whose measured SSIM still meets a target — smallest file per image, a few extra encodes)

Uses `proc_open` when `shell_exec` / `exec` are disabled (common on hardened PHP-FPM hosts).

### Low-memory resize (always netpbm)

| Format | Pipeline |
|--------|----------|
| JPEG | `djpeg` → `pamscale -filter=lanczos` → `cjpeg` → `cwebp` |
| PNG | `pngtopnm` → `pamscale -filter=lanczos` → `pnmtopng` → `cwebp` |
| GIF | `giftopnm` → `pamscale -filter=lanczos` → `ppmtogif` → `cwebp` |

If `pamscale` is missing, falls back to `pnmscale` (no Lanczos). ImageMagick is not used for resize.

## Install

```bash
# Copy or symlink into wp-content/plugins/
ln -s "/path/to/itt-webp-compressor" /var/www/html/wp-content/plugins/itt-webp-compressor

# Server tools (AL2023)
sudo dnf install -y libwebp-tools libjpeg-turbo-tools netpbm-progs
```

Activate **IT&T WebP Compressor** in WP Admin → Plugins. **Deactivate plus-webp** (or wp-itt-toolbox image hooks) before activating — use **one** converter only.

## Settings

**Settings → WebP Compressor**

| Option | Default | Notes |
|--------|---------|-------|
| Processing mode | Auto | Use **Always low memory** on 512MB Ohara hosts |
| Quality strategy | Fixed | `Fixed` (1 pass) · `Content-aware` (netpbm sampling, 1 pass) · `SSIM target` (best compression, up to 5 passes — CPU, not RAM). Keep **Fixed** on 512MB hosts unless uploads are light. |
| Default quality | 70 | Base for cwebp (Fixed / Content-aware). Ignored when strategy is SSIM target. |
| SSIM target | 0.99 | SSIM-target only. `0.995` ≈ visually lossless, `0.99` high, `0.97` balanced, `0.95` aggressive. |
| PNG mode | Lossy | `Lossless` (exact, largest) · `Near-lossless` (smaller) · `Lossy` (smallest — best for photographic PNGs). JPEG/GIF are always lossy. |
| Max dimension | 2560 | Resize before WebP |
| High memory threshold | 500 MB | Auto mode switches above this RAM |

> **SSIM targeting** uses cwebp's own `-print_ssim`, so each pass yields a candidate file and its quality in one process — no separate compare tool. It varies only `-q`, so it applies to lossy encodes (JPEG/GIF, and PNG in Near-lossless / Lossy mode). The extra encodes cost CPU/wall-clock, not memory — `-low_memory` keeps RAM bounded — but on `pm.max_children 2` hosts they slow concurrent uploads, so it is off by default.

## Ohara fleet (512MB–1GB hosts)

Recommended for Town Tavern, North Nowra Tavern, and other low-RAM AL2023 instances:

| Setting | Value |
|---------|-------|
| Processing mode | **Always low memory** |
| Max dimension | 2560 (or 2048 if uploads still fail) |
| PHP-FPM | `memory_limit` 96M, `pm.max_children` 2 (see wp-ansible `AGENTS.md`) |
| Swap | Verify `swapon --show` — playbook creates 1GB `/swapfile` |

**SSH aliases** (Ohara): `~/.ssh/ohara/config` — e.g. `north` = North Nowra Tavern (`northnowratavern.com.au`), `town` = Town Tavern Blacktown (`towntavern.com.au`). Docroot may be `/home/ec2-user/html` or `/usr/share/nginx/html` — verify per host.

### Migration from plus-webp

1. Note current plus-webp quality / max size settings.
2. Activate **IT&T WebP Compressor** with matching settings; deactivate **plus-webp**.
3. Existing media is unchanged — only **new uploads** use the new pipeline.
4. Optional: bulk reconvert is out of scope for this plugin; use WP-CLI or a one-off script if needed.

## Production incident notes (North Nowra Tavern, June 2026)

Full write-up: [wp-ansible/docs/town-tover-images.md](../../wp-ansible/docs/town-tover-images.md).

| Issue | Cause | This plugin helps how |
|-------|--------|------------------------|
| `69.webp` **0 bytes** after upload | Legacy **plus-webp** + PHP-FPM crash (419MB RAM host) mid-conversion | CLI pipeline avoids loading full bitmaps in PHP; still need stable FPM/swap |
| Duplicate `-scaled` + original JPEGs | Default WP `big_image_size_threshold` | Disabled; metadata hook removes stray `-scaled` / `original_image` |
| 503 MB uploads folder / slow admin | Thousands of unused library items + large JPEGs | Pair with [unused media cleanup](../../wp-ansible/modules/7_cleanup/) — not this plugin |
| Broken images on site | Deleted Elementor attachment (ID 877), missing metadata | **Not fixed by WebP** — repair in Elementor / `wp media regenerate` |
| Orphan `.webp` on disk | Legacy plus-webp sidecar files | Cleanup script collects same-stem siblings; cron in `modules/7_cleanup` |

After any failed upload: check for **0-byte** `.webp` in the month folder and delete; re-upload or run conversion manually.

## Related tooling

| Tool | Repo path | Purpose |
|------|-----------|---------|
| Unused media cleanup | [wp-ansible/modules/7_cleanup](../../wp-ansible/modules/7_cleanup/) | Monthly cron: audit → backup (outside webroot) → delete unused Media Library items |
| Image repair (one-off) | [wp-ansible/modules/7_cleanup/files/north-fix-images.php](../../wp-ansible/modules/7_cleanup/files/north-fix-images.php) | Elementor broken refs / metadata regen (site-specific IDs) |
| Media audit report | [wp-ansible/docs/town-tover-images.md](../../wp-ansible/docs/town-tover-images.md) | North Nowra unused vs used media analysis |

Deploy cleanup (does **not** install this plugin):

```bash
ansible-playbook -i inventory/ohara-hotels.ini modules/7_cleanup/playbook.yml --limit north
```

## Troubleshooting

### Upload fails or empty WebP (0 bytes)

- Check **Settings → WebP Compressor → System status** (`cwebp`, `djpeg`, netpbm present).
- Confirm swap: `swapon --show`.
- Review nginx error log for `recv() failed` / PHP-FPM died during `async-upload.php`.
- Set processing mode to **Always low memory**.
- Upload smaller source files (≤2048px) before adding to Elementor on 512MB hosts.

### Thumbnails missing / Elementor warnings (`image.php` line 113)

- Run `wp media regenerate <id> --only-missing` for affected attachments.
- Not caused by WebP conversion alone — often missing `_wp_attachment_metadata`.

### Disk still full after WebP

- WebP reduces **new** upload size; old JPEG/MP4 bulk remains until [media cleanup](../../wp-ansible/modules/7_cleanup/) or manual delete.
- Instagram Feed cache (`sb-instagram-feed-images/`) is separate — purge in Smash Balloon settings.

### Admin shows JPEG in library but URL serves WebP

- Expected after conversion: `_wp_attached_file` should point to `.webp` for new uploads.
- Legacy plus-webp sites may still have `.jpg` in DB with extra `.webp` siblings on disk.

## vs wp-itt-toolbox

This plugin contains only upload WebP conversion. It does not include Cloudflare resizer, WooCommerce gallery, order archiver, or filename renaming.

Use **one** of the two for upload conversion to avoid duplicate hooks.

## Source files (wp-itt-toolbox)

- `includes/image-processing/DynamicMemoryCWebPProcessor.php`
- `includes/image-processing/processors/CWebPProcessor.php`
- `includes/image-processing/processors/LowMemoryResizeProcessor.php`
- `includes/image-processing/memory/MemoryManager.php`

## Plugin layout

```
itt-webp-compressor/
├── itt-webp-compressor.php
├── admin/class-admin.php
└── includes/
    ├── class-webp-upload-processor.php
    ├── processors/   # cwebp, low-memory resize, imagick (high-RAM only)
    ├── memory/
    └── utils/        # command runner, binary finder
```
