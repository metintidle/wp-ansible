<?php
/**
 * Plugin Name: IT&T WebP Compressor
 * Description: Converts uploads to WebP using cwebp with low-memory streaming resize (djpeg/cjpeg, netpbm, ImageMagick limited).
 * Version: 1.5.0
 * Author: Meti Nejati
 * License: GPLv2 or later
 * Text Domain: itt-webp-compressor
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ITT_WEBP_VERSION', '1.5.0');
define('ITT_WEBP_PLUGIN_FILE', __FILE__);
define('ITT_WEBP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('ITT_WEBP_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once ITT_WEBP_PLUGIN_PATH . 'includes/utils/class-command-runner.php';
require_once ITT_WEBP_PLUGIN_PATH . 'includes/utils/class-binary-finder.php';
require_once ITT_WEBP_PLUGIN_PATH . 'includes/memory/class-memory-manager.php';
require_once ITT_WEBP_PLUGIN_PATH . 'includes/processors/class-low-memory-resize-processor.php';
require_once ITT_WEBP_PLUGIN_PATH . 'includes/processors/class-cwebp-processor.php';
require_once ITT_WEBP_PLUGIN_PATH . 'includes/processors/class-imagemagick-processor.php';
require_once ITT_WEBP_PLUGIN_PATH . 'includes/class-webp-upload-processor.php';

if (is_admin()) {
    require_once ITT_WEBP_PLUGIN_PATH . 'admin/class-admin.php';
    ITT_WebP_Admin::init();
}

/**
 * Bootstrap upload processor.
 */
function itt_webp_compressor_init() {
    global $itt_webp_processor;

    if (!isset($itt_webp_processor)) {
        $itt_webp_processor = new ITT_WebP_Upload_Processor();
    }
}
add_action('plugins_loaded', 'itt_webp_compressor_init');

register_activation_hook(__FILE__, function () {
    add_option('itt_webp_quality', 70);
    add_option('itt_webp_max_dimension', 2560);
    add_option('itt_webp_processing_mode', 'auto');
    add_option('itt_webp_high_memory_threshold_mb', 500);
    add_option('itt_webp_png_mode', 'lossy');
});
