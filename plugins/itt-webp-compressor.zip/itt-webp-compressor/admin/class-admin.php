<?php
/**
 * Settings and system status page.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_Admin {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
    }

    public static function add_menu() {
        add_options_page(
            __('IT&T WebP Compressor', 'itt-webp-compressor'),
            __('WebP Compressor', 'itt-webp-compressor'),
            'manage_options',
            'itt-webp-compressor',
            array(__CLASS__, 'render_page')
        );
    }

    public static function register_settings() {
        register_setting('itt_webp_settings', 'itt_webp_quality', array(
            'type' => 'integer',
            'sanitize_callback' => function ($value) {
                return max(1, min(100, (int) $value));
            },
            'default' => 70,
        ));

        register_setting('itt_webp_settings', 'itt_webp_max_dimension', array(
            'type' => 'integer',
            'sanitize_callback' => function ($value) {
                return max(800, min(8192, (int) $value));
            },
            'default' => 2560,
        ));

        register_setting('itt_webp_settings', 'itt_webp_processing_mode', array(
            'type' => 'string',
            'sanitize_callback' => function ($value) {
                return in_array($value, array('auto', 'low', 'high'), true) ? $value : 'auto';
            },
            'default' => 'auto',
        ));

        register_setting('itt_webp_settings', 'itt_webp_high_memory_threshold_mb', array(
            'type' => 'integer',
            'sanitize_callback' => function ($value) {
                return max(100, min(4096, (int) $value));
            },
            'default' => 500,
        ));

        register_setting('itt_webp_settings', 'itt_webp_quality_strategy', array(
            'type' => 'string',
            'sanitize_callback' => function ($value) {
                return in_array($value, array('fixed', 'content', 'ssim'), true) ? $value : 'fixed';
            },
            'default' => 'fixed',
        ));

        register_setting('itt_webp_settings', 'itt_webp_ssim_target', array(
            'type' => 'number',
            'sanitize_callback' => function ($value) {
                return max(0.80, min(0.999, (float) $value));
            },
            'default' => 0.99,
        ));

        register_setting('itt_webp_settings', 'itt_webp_png_mode', array(
            'type' => 'string',
            'sanitize_callback' => function ($value) {
                return in_array($value, array('lossless', 'near_lossless', 'lossy'), true) ? $value : 'lossy';
            },
            'default' => 'lossy',
        ));
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        global $itt_webp_processor;
        $status = ($itt_webp_processor instanceof ITT_WebP_Upload_Processor)
            ? $itt_webp_processor->get_system_status()
            : array();

        $memory = $status['memory_status'] ?? array();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('IT&T WebP Compressor', 'itt-webp-compressor'); ?></h1>
            <p><?php esc_html_e('Converts the main upload to WebP (replaces full original and -scaled). WordPress still generates normal thumbnails (medium, large, etc.).', 'itt-webp-compressor'); ?></p>

            <h2><?php esc_html_e('System status', 'itt-webp-compressor'); ?></h2>
            <table class="widefat striped" style="max-width: 720px;">
                <tbody>
                    <tr>
                        <th>cwebp</th>
                        <td><code><?php echo esc_html($status['cwebp_path'] ?? 'Unknown'); ?></code></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Command runner', 'itt-webp-compressor'); ?></th>
                        <td><code><?php echo esc_html($status['command_runner'] ?? 'unknown'); ?></code></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Active mode', 'itt-webp-compressor'); ?></th>
                        <td><?php echo esc_html($status['processing_mode'] ?? 'Unknown'); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Low-memory tools', 'itt-webp-compressor'); ?></th>
                        <td><?php echo esc_html(implode(', ', $status['low_memory_tools'] ?? array())); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Available RAM', 'itt-webp-compressor'); ?></th>
                        <td><?php echo esc_html(self::format_bytes($memory['effective_available'] ?? 0)); ?></td>
                    </tr>
                    <tr>
                        <th>Imagick</th>
                        <td><?php echo !empty($status['imagick_available']) ? esc_html__('Yes', 'itt-webp-compressor') : esc_html__('No', 'itt-webp-compressor'); ?></td>
                    </tr>
                </tbody>
            </table>

            <form method="post" action="options.php" style="margin-top: 24px; max-width: 720px;">
                <?php settings_fields('itt_webp_settings'); ?>

                <h2><?php esc_html_e('Settings', 'itt-webp-compressor'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="itt_webp_quality_strategy"><?php esc_html_e('Quality strategy', 'itt-webp-compressor'); ?></label></th>
                        <td>
                            <select name="itt_webp_quality_strategy" id="itt_webp_quality_strategy">
                                <?php
                                $strategy = get_option('itt_webp_quality_strategy', 'fixed');
                                $strategies = array(
                                    'fixed' => __('Fixed quality (fastest — one pass)', 'itt-webp-compressor'),
                                    'content' => __('Content-aware (netpbm sampling — one pass)', 'itt-webp-compressor'),
                                    'ssim' => __('SSIM target (best per-image compression — slower, up to 5 passes)', 'itt-webp-compressor'),
                                );
                                foreach ($strategies as $value => $label) {
                                    printf(
                                        '<option value="%s" %s>%s</option>',
                                        esc_attr($value),
                                        selected($strategy, $value, false),
                                        esc_html($label)
                                    );
                                }
                                ?>
                            </select>
                            <p class="description"><?php esc_html_e('SSIM target finds the smallest file that still meets a quality threshold per image. It re-encodes a few times — leave on Fixed for 512MB hosts unless uploads are light.', 'itt-webp-compressor'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="itt_webp_quality"><?php esc_html_e('Default quality', 'itt-webp-compressor'); ?></label></th>
                        <td>
                            <input name="itt_webp_quality" id="itt_webp_quality" type="number" min="1" max="100"
                                   value="<?php echo esc_attr(get_option('itt_webp_quality', 70)); ?>" class="small-text">
                            <p class="description"><?php esc_html_e('Base WebP quality for Fixed and Content-aware strategies. Ignored when Quality strategy is SSIM target.', 'itt-webp-compressor'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="itt_webp_ssim_target"><?php esc_html_e('SSIM target', 'itt-webp-compressor'); ?></label></th>
                        <td>
                            <input name="itt_webp_ssim_target" id="itt_webp_ssim_target" type="number" min="0.80" max="0.999" step="0.005"
                                   value="<?php echo esc_attr(get_option('itt_webp_ssim_target', 0.99)); ?>" class="small-text">
                            <p class="description"><?php esc_html_e('Used only by the SSIM target strategy. 0.995 ≈ visually lossless, 0.99 high, 0.97 balanced, 0.95 aggressive.', 'itt-webp-compressor'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="itt_webp_png_mode"><?php esc_html_e('PNG mode', 'itt-webp-compressor'); ?></label></th>
                        <td>
                            <select name="itt_webp_png_mode" id="itt_webp_png_mode">
                                <?php
                                $png_mode = get_option('itt_webp_png_mode', 'lossy');
                                $png_modes = array(
                                    'lossy' => __('Lossy (smallest — best for photographic PNGs — default)', 'itt-webp-compressor'),
                                    'near_lossless' => __('Near-lossless (near-exact, smaller)', 'itt-webp-compressor'),
                                    'lossless' => __('Lossless (exact, largest)', 'itt-webp-compressor'),
                                );
                                foreach ($png_modes as $value => $label) {
                                    printf(
                                        '<option value="%s" %s>%s</option>',
                                        esc_attr($value),
                                        selected($png_mode, $value, false),
                                        esc_html($label)
                                    );
                                }
                                ?>
                            </select>
                            <p class="description"><?php esc_html_e('JPEG/GIF are always lossy. SSIM targeting applies to PNGs only in Near-lossless or Lossy mode.', 'itt-webp-compressor'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="itt_webp_max_dimension"><?php esc_html_e('Max dimension (px)', 'itt-webp-compressor'); ?></label></th>
                        <td>
                            <input name="itt_webp_max_dimension" id="itt_webp_max_dimension" type="number" min="800" max="8192"
                                   value="<?php echo esc_attr(get_option('itt_webp_max_dimension', 2560)); ?>" class="small-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="itt_webp_processing_mode"><?php esc_html_e('Processing mode', 'itt-webp-compressor'); ?></label></th>
                        <td>
                            <select name="itt_webp_processing_mode" id="itt_webp_processing_mode">
                                <?php
                                $mode = get_option('itt_webp_processing_mode', 'auto');
                                $options = array(
                                    'auto' => __('Auto (low memory unless 500MB+ free)', 'itt-webp-compressor'),
                                    'low' => __('Always low memory (recommended for 512MB hosts)', 'itt-webp-compressor'),
                                    'high' => __('Always Imagick (needs PHP imagick + RAM)', 'itt-webp-compressor'),
                                );
                                foreach ($options as $value => $label) {
                                    printf(
                                        '<option value="%s" %s>%s</option>',
                                        esc_attr($value),
                                        selected($mode, $value, false),
                                        esc_html($label)
                                    );
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="itt_webp_high_memory_threshold_mb"><?php esc_html_e('Auto high-memory threshold (MB)', 'itt-webp-compressor'); ?></label></th>
                        <td>
                            <input name="itt_webp_high_memory_threshold_mb" id="itt_webp_high_memory_threshold_mb"
                                   type="number" min="100" max="4096"
                                   value="<?php echo esc_attr(get_option('itt_webp_high_memory_threshold_mb', 500)); ?>" class="small-text">
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>

            <h2><?php esc_html_e('Server packages (Amazon Linux 2023)', 'itt-webp-compressor'); ?></h2>
            <pre style="background:#f6f7f7;padding:12px;max-width:720px;">sudo dnf install -y libwebp-tools libjpeg-turbo-utils netpbm-progs</pre>
            <p class="description"><?php esc_html_e('Resize always uses netpbm: pamscale with Lanczos when available, otherwise pnmscale.', 'itt-webp-compressor'); ?></p>
        </div>
        <?php
    }

    private static function format_bytes($bytes) {
        if ($bytes <= 0) {
            return __('Unknown', 'itt-webp-compressor');
        }

        return round($bytes / 1024 / 1024, 1) . ' MB';
    }
}
