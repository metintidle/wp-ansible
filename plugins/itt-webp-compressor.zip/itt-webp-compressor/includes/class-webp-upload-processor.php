<?php
/**
 * Coordinates memory-aware WebP conversion on upload.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_Upload_Processor {

    /** @var string|false */
    private $cwebp_path;

    /** @var ITT_WebP_Memory_Manager */
    private $memory_manager;

    /** @var ITT_WebP_CWebP_Processor|null */
    private $cwebp_processor;

    /** @var ITT_WebP_Low_Memory_Resize_Processor */
    private $low_memory_processor;

    /** @var ITT_WebP_ImageMagick_Processor */
    private $imagick_processor;

    /**
     * JPEG/PNG copies stashed before WebP overwrite, keyed by tmp path.
     *
     * @var array<string, array{sidecar: string, ext: string}>
     */
    private $pending_jpeg = array();

    public function __construct() {
        $this->cwebp_path = ITT_WebP_Binary_Finder::find_cwebp();
        $this->memory_manager = new ITT_WebP_Memory_Manager();
        $this->low_memory_processor = new ITT_WebP_Low_Memory_Resize_Processor();
        $this->imagick_processor = new ITT_WebP_ImageMagick_Processor();

        if ($this->cwebp_path) {
            $this->cwebp_processor = new ITT_WebP_CWebP_Processor($this->cwebp_path);
        }

        add_action('init', array($this, 'register_hooks'));
    }

    public function register_hooks() {
        if (!ITT_WebP_Command_Runner::is_available()) {
            add_action('admin_notices', array($this, 'missing_command_runner_notice'));
            return;
        }

        if (!$this->cwebp_path) {
            add_action('admin_notices', array($this, 'missing_cwebp_notice'));
            return;
        }

        // Resize happens in our pipeline — never let WP keep a huge original plus a -scaled copy.
        add_filter('big_image_size_threshold', '__return_false', 999);

        add_filter('wp_handle_upload_prefilter', array($this, 'process_upload'), 10);
        add_filter('wp_handle_upload', array($this, 'write_jpeg_sidecars'), 20, 2);
        add_filter('wp_generate_attachment_metadata', array($this, 'remove_duplicate_scaled_and_original'), 20, 2);
    }

    /**
     * Keep JPEG/PNG on disk next to WebP so Elementor hardcoded .jpg / -scaled.jpg URLs still 200.
     * Default on — Ohara Elementor sites broke when originals were deleted.
     */
    public static function keep_jpeg_enabled() {
        return (string) get_option('itt_webp_keep_jpeg', '1') !== '0';
    }

    /**
     * Ensure only one WebP remains: drop WP -scaled subsizes and backup originals.
     *
     * @param array $metadata Attachment metadata.
     * @param int   $attachment_id Attachment post ID.
     * @return array
     */
    public function remove_duplicate_scaled_and_original($metadata, $attachment_id) {
        if (self::keep_jpeg_enabled()) {
            return $metadata;
        }

        if (empty($metadata['file']) || !wp_attachment_is_image($attachment_id)) {
            return $metadata;
        }

        $upload_dir = wp_upload_dir();
        if (!empty($upload_dir['error'])) {
            return $metadata;
        }

        $base_dir = trailingslashit($upload_dir['basedir']);
        $main_rel = $metadata['file'];
        $main_abs = $base_dir . $main_rel;

        if (!file_exists($main_abs) || !$this->path_is_webp($main_abs)) {
            return $metadata;
        }

        // WP may still register a -scaled subsize; remove file and metadata entry.
        if (!empty($metadata['sizes']['scaled']['file'])) {
            $scaled_abs = $base_dir . dirname($main_rel) . '/' . $metadata['sizes']['scaled']['file'];
            if ($scaled_abs !== $main_abs && file_exists($scaled_abs)) {
                wp_delete_file($scaled_abs);
            }
            unset($metadata['sizes']['scaled']);
        }

        // WP 5.3+ can keep the pre-scale original (e.g. huge JPEG next to -scaled.webp).
        if (!empty($metadata['original_image'])) {
            $original_abs = $base_dir . dirname($main_rel) . '/' . $metadata['original_image'];
            if ($original_abs !== $main_abs && file_exists($original_abs)) {
                wp_delete_file($original_abs);
            }
            unset($metadata['original_image']);
        }

        return $metadata;
    }

    private function path_is_webp($path) {
        return strtolower(pathinfo($path, PATHINFO_EXTENSION)) === 'webp';
    }

    /**
     * @param array $file Upload file array.
     * @return array
     */
    public function process_upload($file) {
        if (!$this->cwebp_processor || !$this->is_processable_image($file['type'])) {
            return $file;
        }

        $path = $file['tmp_name'];
        $info = @getimagesize($path);

        if (!$info) {
            return $file;
        }

        $width = (int) $info[0];
        $height = (int) $info[1];
        $original_size = filesize($path);
        $start = microtime(true);

        $use_high_memory = $this->should_use_high_memory_mode();
        $orig_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        try {
            if ($use_high_memory) {
                $result = $this->process_high_memory($path, $width, $height, $file['type'], $orig_ext);
            } else {
                $result = $this->process_low_memory($path, $width, $height, $file['type'], $orig_ext);
            }

            if (!empty($result['success'])) {
                $file['name'] = $this->replace_extension($file['name'], 'webp');
                $file['type'] = 'image/webp';

                if (defined('WP_DEBUG') && WP_DEBUG) {
                    $final_size = filesize($path);
                    $ratio = $original_size > 0
                        ? round((($original_size - $final_size) / $original_size) * 100, 1)
                        : 0;
                    $elapsed = round(microtime(true) - $start, 2);

                    $quality_note = isset($result['quality']) ? ' q=' . $result['quality'] : '';
                    if (isset($result['ssim']) && $result['ssim'] !== null) {
                        $quality_note .= ' ssim=' . $result['ssim'];
                    }

                    error_log(sprintf(
                        'ITT WebP: %s — %s%% smaller in %ss (%dx%d)%s',
                        $result['mode'] ?? 'unknown',
                        $ratio,
                        $elapsed,
                        $result['new_width'] ?? $width,
                        $result['new_height'] ?? $height,
                        $quality_note
                    ));
                }
            }
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ITT WebP: ' . $e->getMessage());
            }
        }

        return $file;
    }

    private function should_use_high_memory_mode() {
        $mode = get_option('itt_webp_processing_mode', 'auto');

        if ($mode === 'low') {
            return false;
        }

        if ($mode === 'high') {
            return $this->imagick_processor->is_available();
        }

        $threshold_mb = (int) get_option('itt_webp_high_memory_threshold_mb', 500);
        $threshold = max(100, $threshold_mb) * 1024 * 1024;
        $memory = $this->memory_manager->get_memory_status();

        return $memory['effective_available'] > $threshold && $this->imagick_processor->is_available();
    }

    /**
     * Copy the (resized) original next to the temp file so we can restore .jpg after WP saves WebP.
     */
    private function stash_jpeg_sidecar($path, $orig_ext) {
        if (!self::keep_jpeg_enabled() || !is_readable($path)) {
            return;
        }

        $ext = preg_replace('/[^a-z0-9]/', '', strtolower((string) $orig_ext));
        if ($ext === '') {
            $ext = 'jpg';
        }

        $sidecar = $path . '.itt-keep';
        if (!@copy($path, $sidecar)) {
            return;
        }

        $this->pending_jpeg[$path] = array(
            'sidecar' => $sidecar,
            'ext' => $ext,
        );
    }

    /**
     * Write photo.jpg and photo-scaled.jpg beside the saved WebP.
     *
     * @param array  $upload  WP upload array.
     * @param string $context Upload context.
     * @return array
     */
    public function write_jpeg_sidecars($upload, $context) {
        unset($context);

        if (!self::keep_jpeg_enabled() || empty($this->pending_jpeg) || empty($upload['file'])) {
            return $upload;
        }

        $info = null;
        $key = null;
        foreach ($this->pending_jpeg as $tmp => $meta) {
            if (!empty($meta['sidecar']) && file_exists($meta['sidecar'])) {
                $info = $meta;
                $key = $tmp;
                break;
            }
        }

        if (!$info) {
            return $upload;
        }

        $dest_dir = dirname($upload['file']);
        $stem = pathinfo($upload['file'], PATHINFO_FILENAME);
        $ext = $info['ext'];

        $jpeg_path = $dest_dir . '/' . $stem . '.' . $ext;
        $scaled_path = $dest_dir . '/' . $stem . '-scaled.' . $ext;

        if (!file_exists($jpeg_path)) {
            @copy($info['sidecar'], $jpeg_path);
        }
        if (!file_exists($scaled_path) && $scaled_path !== $jpeg_path) {
            @copy($info['sidecar'], $scaled_path);
        }

        @unlink($info['sidecar']);
        unset($this->pending_jpeg[$key]);

        return $upload;
    }

    private function process_high_memory($path, $width, $height, $mime_type, $orig_ext = 'jpg') {
        try {
            $this->stash_jpeg_sidecar($path, $orig_ext);
            $result = $this->imagick_processor->process_fast($path, $width, $height, $mime_type);
            $result['mode'] = 'HIGH MEMORY';
            return $result;
        } catch (Exception $e) {
            return $this->process_low_memory($path, $width, $height, $mime_type, $orig_ext);
        }
    }

    private function process_low_memory($path, $width, $height, $mime_type, $orig_ext = 'jpg') {
        $max_dim = (int) get_option('itt_webp_max_dimension', 2560);
        $this->low_memory_processor->set_max_dimension($max_dim);

        $resize = $this->low_memory_processor->resize_if_needed($path, $width, $height, $mime_type);

        if (empty($resize['success'])) {
            return array(
                'success' => false,
                'mode' => 'LOW MEMORY',
                'error' => $resize['error'] ?? 'Resize failed',
            );
        }

        $this->stash_jpeg_sidecar($path, $orig_ext);

        $quality = (int) get_option('itt_webp_quality', 70);
        $options = array(
            'strategy' => get_option('itt_webp_quality_strategy', 'fixed'),
            'ssim_target' => (float) get_option('itt_webp_ssim_target', 0.99),
            'png_mode' => get_option('itt_webp_png_mode', 'lossy'),
        );
        $webp = $this->cwebp_processor->convert_only($path, $mime_type, $quality, $options);

        if (empty($webp['success'])) {
            return array(
                'success' => false,
                'mode' => 'LOW MEMORY',
                'error' => $webp['error'] ?? 'WebP conversion failed',
            );
        }

        return array(
            'success' => true,
            'mode' => 'LOW MEMORY',
            'method' => ($resize['method'] ?? 'resize') . ' + cwebp -low_memory',
            'resized' => !empty($resize['resized']),
            'new_width' => $resize['new_width'] ?? $width,
            'new_height' => $resize['new_height'] ?? $height,
            'quality' => $webp['quality'] ?? $quality,
            'ssim' => $webp['ssim'] ?? null,
        );
    }

    private function is_processable_image($mime_type) {
        return in_array($mime_type, array('image/jpeg', 'image/png', 'image/gif'), true);
    }

    private function replace_extension($filename, $extension) {
        $base = pathinfo($filename, PATHINFO_FILENAME);
        return $base . '.' . ltrim($extension, '.');
    }

    public function missing_cwebp_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html__('IT&T WebP Compressor: cwebp not found. Install libwebp-tools:', 'itt-webp-compressor');
        echo ' <code>sudo dnf install libwebp-tools</code>';
        echo '</p></div>';
    }

    public function missing_command_runner_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html__('IT&T WebP Compressor: shell_exec, exec, and proc_open are all disabled. Ask your host to enable proc_open for PHP-FPM.', 'itt-webp-compressor');
        echo '</p></div>';
    }

    /**
     * @return array<string, mixed>
     */
    public function get_system_status() {
        $memory = $this->memory_manager->get_memory_status();

        return array(
            'cwebp_path' => $this->cwebp_path ?: 'Not found',
            'cwebp_available' => !empty($this->cwebp_path),
            'command_runner' => ITT_WebP_Command_Runner::get_mode(),
            'command_runner_available' => ITT_WebP_Command_Runner::is_available(),
            'imagick_available' => $this->imagick_processor->is_available(),
            'low_memory_tools' => $this->low_memory_processor->get_available_tools(),
            'memory_status' => $memory,
            'processing_mode' => $this->should_use_high_memory_mode() ? 'High Memory' : 'Low Memory',
            'settings' => array(
                'quality' => (int) get_option('itt_webp_quality', 70),
                'max_dimension' => (int) get_option('itt_webp_max_dimension', 2560),
                'mode' => get_option('itt_webp_processing_mode', 'auto'),
                'quality_strategy' => get_option('itt_webp_quality_strategy', 'fixed'),
                'ssim_target' => (float) get_option('itt_webp_ssim_target', 0.99),
                'png_mode' => get_option('itt_webp_png_mode', 'lossy'),
                'keep_jpeg' => self::keep_jpeg_enabled() ? '1' : '0',
            ),
        );
    }
}
