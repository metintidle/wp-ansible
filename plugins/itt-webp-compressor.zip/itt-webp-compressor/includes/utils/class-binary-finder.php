<?php
/**
 * Locate system binaries (cwebp).
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_Binary_Finder {

    /**
     * @return string|false
     */
    public static function find_cwebp() {
        $paths = array(
            '/opt/homebrew/bin/cwebp',
            '/usr/local/bin/cwebp',
            '/usr/bin/cwebp',
        );

        foreach ($paths as $path) {
            if (@is_executable($path)) {
                return $path;
            }
        }

        return self::resolve_from_path('cwebp');
    }

    /**
     * @param string $name Binary name.
     * @return string|false
     */
    public static function find_binary($name) {
        $paths = array(
            '/opt/homebrew/bin/' . $name,
            '/usr/local/bin/' . $name,
            '/usr/bin/' . $name,
        );

        foreach ($paths as $path) {
            if (@is_executable($path)) {
                return $path;
            }
        }

        return self::resolve_from_path($name);
    }

    /**
     * @param string $name Binary name.
     * @return string|false
     */
    private static function resolve_from_path($name) {
        if (!ITT_WebP_Command_Runner::is_available()) {
            return false;
        }

        $return_code = 0;
        $output = ITT_WebP_Command_Runner::run(
            'command -v ' . escapeshellarg($name) . ' 2>/dev/null',
            $return_code
        );

        if ($return_code !== 0 || trim($output) === '') {
            return false;
        }

        $resolved = trim(strtok($output, "\n"));

        return (@is_executable($resolved)) ? $resolved : false;
    }
}
