<?php
/**
 * Run shell commands via proc_open when shell_exec/exec are disabled.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_Command_Runner {

    /**
     * @return bool
     */
    public static function is_available() {
        return self::function_available('proc_open')
            || self::function_available('shell_exec')
            || self::function_available('exec');
    }

    /**
     * @return string shell_exec|exec|proc_open|none
     */
    public static function get_mode() {
        if (self::function_available('shell_exec')) {
            return 'shell_exec';
        }
        if (self::function_available('exec')) {
            return 'exec';
        }
        if (self::function_available('proc_open')) {
            return 'proc_open';
        }

        return 'none';
    }

    /**
     * Run a shell command (supports redirects, pipes, 2>&1).
     *
     * @param string $command Full shell command string.
     * @param int    $return_code Exit code (by reference).
     * @return string Combined stdout + stderr.
     */
    public static function run($command, &$return_code = 0) {
        if (self::function_available('shell_exec')) {
            $output = shell_exec($command);
            $return_code = ($output === null) ? 1 : 0;

            return $output ?? '';
        }

        if (self::function_available('exec')) {
            $lines = array();
            exec($command, $lines, $return_code);

            return implode("\n", $lines);
        }

        if (self::function_available('proc_open')) {
            return self::proc_run_shell($command, $return_code);
        }

        $return_code = 127;

        return '';
    }

    /**
     * @param string $command Shell command.
     * @return int Exit code.
     */
    public static function run_silent($command) {
        $return_code = 0;
        self::run($command, $return_code);

        return $return_code;
    }

    /**
     * @param string $command Shell command.
     * @param int    $return_code Exit code (by reference).
     * @return string
     */
    private static function proc_run_shell($command, &$return_code) {
        $shell = self::find_shell();
        $descriptors = array(
            0 => array('pipe', 'r'),
            1 => array('pipe', 'w'),
            2 => array('pipe', 'w'),
        );

        $process = @proc_open(
            array($shell, '-c', $command),
            $descriptors,
            $pipes
        );

        if (!is_resource($process)) {
            $return_code = -1;

            return '';
        }

        fclose($pipes[0]);
        $stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);
        $return_code = proc_close($process);

        return $stdout . $stderr;
    }

    /**
     * @return string
     */
    private static function find_shell() {
        foreach (array('/bin/bash', '/bin/sh') as $candidate) {
            if (@is_executable($candidate)) {
                return $candidate;
            }
        }

        return '/bin/sh';
    }

    /**
     * @param string $name Function name.
     * @return bool
     */
    private static function function_available($name) {
        if (!function_exists($name)) {
            return false;
        }

        static $disabled = null;

        if ($disabled === null) {
            $raw = (string) ini_get('disable_functions');
            $disabled = $raw === '' ? array() : array_map('trim', explode(',', $raw));
        }

        return !in_array($name, $disabled, true);
    }
}
