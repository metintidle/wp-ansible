<?php
/**
 * Low-memory resize via netpbm only: decode → pamscale/pnmscale (Lanczos) → encode.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_Low_Memory_Resize_Processor {

    /** @var array<string, mixed>|null */
    private $scale_tool;

    /** @var string|false */
    private $djpeg_path;

    /** @var string|false */
    private $cjpeg_path;

    /** @var string|false */
    private $jpegtopnm_path;

    /** @var string|false */
    private $pngtopnm_path;

    /** @var string|false */
    private $pnmtopng_path;

    /** @var string|false */
    private $giftopnm_path;

    /** @var string|false */
    private $ppmtogif_path;

    private $max_width = 2560;
    private $max_height = 2560;

    public function __construct() {
        $this->detect_tools();
    }

    public function set_max_dimension($max) {
        $max = max(800, (int) $max);
        $this->max_width = $max;
        $this->max_height = $max;
    }

    private function detect_tools() {
        $pamscale = ITT_WebP_Binary_Finder::find_binary('pamscale');
        $pnmscale = ITT_WebP_Binary_Finder::find_binary('pnmscale');

        if ($pamscale) {
            $this->scale_tool = array(
                'path' => $pamscale,
                'name' => 'pamscale',
                'filter' => 'lanczos',
            );
        } elseif ($pnmscale) {
            $this->scale_tool = array(
                'path' => $pnmscale,
                'name' => 'pnmscale',
                'filter' => null,
            );
        }

        $this->djpeg_path = ITT_WebP_Binary_Finder::find_binary('djpeg');
        $this->cjpeg_path = ITT_WebP_Binary_Finder::find_binary('cjpeg');
        $this->jpegtopnm_path = ITT_WebP_Binary_Finder::find_binary('jpegtopnm');
        $this->pngtopnm_path = ITT_WebP_Binary_Finder::find_binary('pngtopnm');
        $this->pnmtopng_path = ITT_WebP_Binary_Finder::find_binary('pnmtopng');
        $this->giftopnm_path = ITT_WebP_Binary_Finder::find_binary('giftopnm');
        $this->ppmtogif_path = ITT_WebP_Binary_Finder::find_binary('ppmtogif');
    }

    /**
     * @return array<string, mixed>
     */
    public function resize_if_needed($file_path, $width, $height, $mime_type) {
        if ($width <= $this->max_width && $height <= $this->max_height) {
            return array(
                'success' => true,
                'resized' => false,
                'method' => 'No resize needed',
                'new_width' => $width,
                'new_height' => $height,
            );
        }

        if (!$this->scale_tool) {
            return array(
                'success' => false,
                'error' => 'netpbm scaler not found — install netpbm-progs (pamscale or pnmscale)',
            );
        }

        if (!$this->mime_supported($mime_type)) {
            return array(
                'success' => false,
                'error' => 'No netpbm decode/encode tools for ' . $mime_type,
            );
        }

        return $this->resize_via_netpbm($file_path, $width, $height, $mime_type);
    }

    private function mime_supported($mime_type) {
        switch ($mime_type) {
            case 'image/jpeg':
                return ($this->djpeg_path && $this->cjpeg_path) || ($this->jpegtopnm_path && $this->cjpeg_path);
            case 'image/png':
                return $this->pngtopnm_path && $this->pnmtopng_path;
            case 'image/gif':
                return $this->giftopnm_path && $this->ppmtogif_path;
            default:
                return false;
        }
    }

    private function resize_via_netpbm($file_path, $width, $height, $mime_type) {
        $ratio = min($this->max_width / $width, $this->max_height / $height);
        $new_width = (int) ($width * $ratio);
        $new_height = (int) ($height * $ratio);

        $temp_id = uniqid('itt_pnm_', true);
        $temp_dir = sys_get_temp_dir();
        $temp_pnm = $temp_dir . '/' . $temp_id . '.pnm';
        $temp_scaled = $temp_dir . '/' . $temp_id . '_scaled.pnm';
        $temp_out = $temp_dir . '/' . $temp_id . '_out';

        try {
            if (!$this->decode_to_pnm($file_path, $mime_type, $temp_pnm)) {
                throw new Exception('netpbm decode failed');
            }

            if (!$this->scale_pnm($temp_pnm, $temp_scaled, $new_width, $new_height)) {
                throw new Exception($this->scale_tool['name'] . ' resize failed');
            }

            if (!$this->encode_from_pnm($temp_scaled, $temp_out, $mime_type)) {
                throw new Exception('netpbm encode failed');
            }

            if (!file_exists($temp_out) || filesize($temp_out) === 0) {
                throw new Exception('Resize output empty');
            }

            if (!rename($temp_out, $file_path)) {
                throw new Exception('Failed to replace original file');
            }

            $filter_label = $this->scale_tool['filter']
                ? $this->scale_tool['name'] . ' (' . $this->scale_tool['filter'] . ')'
                : $this->scale_tool['name'];

            return array(
                'success' => true,
                'resized' => true,
                'method' => 'netpbm ' . $filter_label,
                'new_width' => $new_width,
                'new_height' => $new_height,
            );
        } catch (Exception $e) {
            return array('success' => false, 'error' => $e->getMessage());
        } finally {
            foreach (array($temp_pnm, $temp_scaled, $temp_out) as $path) {
                if ($path && file_exists($path)) {
                    unlink($path);
                }
            }
        }
    }

    private function decode_to_pnm($file_path, $mime_type, $temp_pnm) {
        switch ($mime_type) {
            case 'image/jpeg':
                if ($this->djpeg_path) {
                    $cmd = escapeshellarg($this->djpeg_path) . ' -pnm -fast '
                        . escapeshellarg($file_path) . ' > ' . escapeshellarg($temp_pnm) . ' 2>/dev/null';
                } else {
                    $cmd = escapeshellarg($this->jpegtopnm_path) . ' '
                        . escapeshellarg($file_path) . ' > ' . escapeshellarg($temp_pnm) . ' 2>/dev/null';
                }
                break;

            case 'image/png':
                $cmd = escapeshellarg($this->pngtopnm_path) . ' '
                    . escapeshellarg($file_path) . ' > ' . escapeshellarg($temp_pnm) . ' 2>/dev/null';
                break;

            case 'image/gif':
                $cmd = escapeshellarg($this->giftopnm_path) . ' '
                    . escapeshellarg($file_path) . ' > ' . escapeshellarg($temp_pnm) . ' 2>/dev/null';
                break;

            default:
                return false;
        }

        ITT_WebP_Command_Runner::run_silent($cmd);

        return file_exists($temp_pnm) && filesize($temp_pnm) > 0;
    }

    private function scale_pnm($input_pnm, $output_pnm, $new_width, $new_height) {
        $cmd = escapeshellarg($this->scale_tool['path']);

        if (!empty($this->scale_tool['filter'])) {
            $cmd .= ' -filter=' . $this->scale_tool['filter'];
        }

        $cmd .= ' -width ' . $new_width . ' -height ' . $new_height;
        $cmd .= ' ' . escapeshellarg($input_pnm);
        $cmd .= ' > ' . escapeshellarg($output_pnm) . ' 2>/dev/null';

        ITT_WebP_Command_Runner::run_silent($cmd);

        return file_exists($output_pnm) && filesize($output_pnm) > 0;
    }

    private function encode_from_pnm($temp_pnm, $temp_out, $mime_type) {
        switch ($mime_type) {
            case 'image/jpeg':
                $cmd = escapeshellarg($this->cjpeg_path);
                $cmd .= ' -quality 85 -optimize -progressive ';
                $cmd .= escapeshellarg($temp_pnm) . ' > ' . escapeshellarg($temp_out) . ' 2>/dev/null';
                break;

            case 'image/png':
                $cmd = escapeshellarg($this->pnmtopng_path) . ' ';
                $cmd .= escapeshellarg($temp_pnm) . ' > ' . escapeshellarg($temp_out) . ' 2>/dev/null';
                break;

            case 'image/gif':
                $cmd = escapeshellarg($this->ppmtogif_path) . ' ';
                $cmd .= escapeshellarg($temp_pnm) . ' > ' . escapeshellarg($temp_out) . ' 2>/dev/null';
                break;

            default:
                return false;
        }

        ITT_WebP_Command_Runner::run_silent($cmd);

        return file_exists($temp_out) && filesize($temp_out) > 0;
    }

    /**
     * @return array<int, string>
     */
    public function get_available_tools() {
        $tools = array();

        if ($this->scale_tool) {
            $label = $this->scale_tool['name'];
            if (!empty($this->scale_tool['filter'])) {
                $label .= ' (' . $this->scale_tool['filter'] . ')';
            }
            $tools[] = $label;
        }

        if ($this->djpeg_path && $this->cjpeg_path) {
            $tools[] = 'JPEG (djpeg/cjpeg)';
        } elseif ($this->jpegtopnm_path && $this->cjpeg_path) {
            $tools[] = 'JPEG (jpegtopnm/cjpeg)';
        }

        if ($this->pngtopnm_path && $this->pnmtopng_path) {
            $tools[] = 'PNG (pngtopnm/pnmtopng)';
        }

        if ($this->giftopnm_path && $this->ppmtogif_path) {
            $tools[] = 'GIF (giftopnm/ppmtogif)';
        }

        return empty($tools)
            ? array('None — install netpbm-progs and libjpeg-turbo-utils')
            : $tools;
    }
}
