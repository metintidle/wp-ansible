<?php
/**
 * Optional high-memory Imagick path when RAM is plentiful.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_ImageMagick_Processor {

    private $max_width = 2560;
    private $max_height = 2560;
    private $webp_quality = 85;

    public function is_available() {
        return extension_loaded('imagick') && class_exists('Imagick');
    }

    /**
     * @return array<string, mixed>
     */
    public function process_fast($file_path, $width, $height, $mime_type) {
        if (!$this->is_available()) {
            throw new Exception('ImageMagick extension not available');
        }

        unset($mime_type);

        $imagick = new Imagick();
        Imagick::setResourceLimit(Imagick::RESOURCETYPE_MEMORY, 128 * 1024 * 1024);
        Imagick::setResourceLimit(Imagick::RESOURCETYPE_MAP, 128 * 1024 * 1024);

        try {
            $max_dim = (int) get_option('itt_webp_max_dimension', 2560);
            $this->max_width = max(800, $max_dim);
            $this->max_height = $this->max_width;

            $imagick->readImage($file_path);
            $imagick->stripImage();

            $needs_resize = ($width > $this->max_width || $height > $this->max_height);
            $new_width = $width;
            $new_height = $height;

            if ($needs_resize) {
                $ratio = min($this->max_width / $width, $this->max_height / $height);
                $new_width = (int) ($width * $ratio);
                $new_height = (int) ($height * $ratio);
                $imagick->resizeImage($new_width, $new_height, Imagick::FILTER_LANCZOS, 1);
            }

            $quality = (int) get_option('itt_webp_quality', 70);
            $imagick->setImageFormat('webp');
            $imagick->setImageCompressionQuality(max(1, min(100, $quality ?: $this->webp_quality)));
            $imagick->writeImage($file_path);

            return array(
                'success' => true,
                'method' => 'ImageMagick Fast',
                'resized' => $needs_resize,
                'new_width' => $new_width,
                'new_height' => $new_height,
            );
        } finally {
            $imagick->clear();
            $imagick->destroy();
        }
    }
}
