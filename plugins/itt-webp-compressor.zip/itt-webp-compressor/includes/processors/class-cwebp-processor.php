<?php
/**
 * cwebp CLI conversion with -low_memory and content-aware quality.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_CWebP_Processor {

    /** @var string */
    private $cwebp_path;

    private $default_quality = 70;
    private $min_quality = 50;
    private $max_quality = 85;

    /** Wider quality bounds + pass budget for the SSIM binary search. */
    private $ssim_min_quality = 40;
    private $ssim_max_quality = 92;
    private $ssim_max_passes = 5;

    public function __construct($cwebp_path) {
        $this->cwebp_path = $cwebp_path;
    }

    /**
     * Convert to WebP in-place without loading the image into PHP memory.
     *
     * @param string   $file_path Source file path.
     * @param string   $mime_type MIME type.
     * @param int|null $quality   Base quality (1-100). Null = use heuristic/default.
     * @param array    $options {
     *     @type string $strategy    'fixed' (default) | 'content' | 'ssim'.
     *     @type float  $ssim_target Linear SSIM (0-1) to reach when strategy is 'ssim'.
     *     @type string $png_mode    'lossy' (default) | 'near_lossless' | 'lossless'.
     * }
     * @return array{success: bool, processing_time?: float, quality?: int, ssim?: float, error?: string}
     */
    public function convert_only($file_path, $mime_type, $quality = null, array $options = array()) {
        $strategy = isset($options['strategy']) ? $options['strategy'] : 'fixed';
        $png_mode = isset($options['png_mode']) ? $options['png_mode'] : 'lossy';

        // Lossless PNG output is already exact, so an SSIM search has nothing to find.
        if ($strategy === 'ssim' && !$this->is_lossless_png($mime_type, $png_mode)) {
            $ssim_target = isset($options['ssim_target']) ? (float) $options['ssim_target'] : 0.99;
            return $this->convert_with_ssim_target($file_path, $mime_type, $png_mode, $ssim_target);
        }

        if ($strategy === 'content') {
            if ($quality !== null) {
                $this->default_quality = max(1, min(100, (int) $quality));
            }
            $resolved_quality = $this->calculate_optimal_quality($file_path, $mime_type);
        } else {
            $resolved_quality = ($quality !== null) ? (int) $quality : $this->default_quality;
        }

        return $this->encode_in_place($file_path, $mime_type, $png_mode, (int) $resolved_quality);
    }

    /**
     * Single-pass encode at a fixed quality.
     *
     * @return array
     */
    private function encode_in_place($file_path, $mime_type, $png_mode, $quality) {
        $temp_webp = $file_path . '.webp.tmp';
        $start = microtime(true);

        $output = $this->run_cwebp($file_path, $temp_webp, $mime_type, $png_mode, $quality, false);
        $processing_time = round(microtime(true) - $start, 2);

        return $this->finalize($temp_webp, $file_path, $processing_time, $quality, null, $output);
    }

    /**
     * Binary-search the lowest quality whose SSIM still meets the target.
     *
     * Uses cwebp's own `-print_ssim`, so each pass yields both a candidate
     * file and its measured SSIM in one process. Only `-q` is varied, so this
     * applies to lossy encodes (JPEG/GIF, and PNG in lossy/near_lossless mode).
     *
     * @return array
     */
    private function convert_with_ssim_target($file_path, $mime_type, $png_mode, $ssim_target) {
        $start = microtime(true);
        $ssim_target = max(0.80, min(0.999, (float) $ssim_target));

        $best_tmp = $file_path . '.webp.best';
        $cur_tmp = $file_path . '.webp.tmp';

        $lo = $this->ssim_min_quality;
        $hi = $this->ssim_max_quality;
        $passes = $this->ssim_max_passes;

        $best_quality = null;
        $best_ssim = null;

        while ($passes-- > 0 && $lo <= $hi) {
            $mid = (int) (($lo + $hi) / 2);
            $ssim = null;
            $this->run_cwebp($file_path, $cur_tmp, $mime_type, $png_mode, $mid, true, $ssim);

            if (!file_exists($cur_tmp) || filesize($cur_tmp) < 1) {
                break; // encode failed — stop searching and fall back below
            }

            if ($ssim === null) {
                // cwebp produced no parseable SSIM; keep this encode and stop.
                @unlink($best_tmp);
                if (@rename($cur_tmp, $best_tmp)) {
                    $best_quality = $mid;
                }
                break;
            }

            if ($ssim >= $ssim_target) {
                // Good enough — remember it as the best-so-far and try lower.
                @unlink($best_tmp);
                if (@rename($cur_tmp, $best_tmp)) {
                    $best_quality = $mid;
                    $best_ssim = $ssim;
                }
                $hi = $mid - 1;
            } else {
                @unlink($cur_tmp);
                $lo = $mid + 1;
            }
        }

        if (file_exists($cur_tmp)) {
            @unlink($cur_tmp);
        }

        // No quality met the target — fall back to a top-quality encode.
        if ($best_quality === null) {
            $fallback_ssim = null;
            $this->run_cwebp($file_path, $best_tmp, $mime_type, $png_mode, $this->ssim_max_quality, true, $fallback_ssim);
            $best_quality = $this->ssim_max_quality;
            $best_ssim = $fallback_ssim;
        }

        $processing_time = round(microtime(true) - $start, 2);

        return $this->finalize($best_tmp, $file_path, $processing_time, $best_quality, $best_ssim, '');
    }

    /**
     * Build and run a single cwebp invocation.
     *
     * @param bool       $measure_ssim Pass `-print_ssim` and parse the result.
     * @param float|null $ssim         Parsed linear SSIM (by reference) when measuring.
     * @return string Combined cwebp output.
     */
    private function run_cwebp($file_path, $out_path, $mime_type, $png_mode, $quality, $measure_ssim, &$ssim = null) {
        $command = escapeshellarg($this->cwebp_path);
        $command .= ' -q ' . max(1, min(100, (int) $quality));
        $command .= ' -m 6';
        $command .= ' -mt';
        $command .= ' -low_memory';
        $command .= $this->format_flags($mime_type, $png_mode);

        // `-quiet` suppresses the distortion print, so only add it when not measuring.
        $command .= $measure_ssim ? ' -print_ssim' : ' -quiet';

        $command .= ' ' . escapeshellarg($file_path);
        $command .= ' -o ' . escapeshellarg($out_path);
        $command .= ' 2>&1';

        $return_code = 0;
        $output = ITT_WebP_Command_Runner::run($command, $return_code);

        if ($measure_ssim) {
            $ssim = $this->parse_ssim($output);
        }

        return $output;
    }

    /**
     * Lossy/lossless flags for the source format. JPEG/GIF are always lossy (`-q`).
     *
     * @return string
     */
    private function format_flags($mime_type, $png_mode) {
        if ($mime_type !== 'image/png') {
            return '';
        }

        switch ($png_mode) {
            case 'lossy':
                return '';
            case 'near_lossless':
                return ' -near_lossless 60';
            case 'lossless':
            default:
                return ' -lossless';
        }
    }

    private function is_lossless_png($mime_type, $png_mode) {
        return $mime_type === 'image/png' && $png_mode === 'lossless';
    }

    /**
     * Parse cwebp's `-print_ssim` output (a dB-scaled "Total") into linear SSIM (0-1).
     *
     * @return float|null
     */
    private function parse_ssim($output) {
        if (!is_string($output) || !preg_match('/Total:\s*([0-9.]+)/', $output, $matches)) {
            return null;
        }

        $db = (float) $matches[1];
        if ($db >= 96.0) {
            return 1.0; // cwebp caps a perfect match near 99 dB
        }

        return 1.0 - pow(10, -$db / 10.0);
    }

    /**
     * Move a finished temp encode over the original, or clean up on failure.
     *
     * @return array
     */
    private function finalize($temp_webp, $file_path, $processing_time, $quality, $ssim, $output) {
        if (file_exists($temp_webp) && filesize($temp_webp) > 0) {
            if (rename($temp_webp, $file_path)) {
                $result = array(
                    'success' => true,
                    'processing_time' => $processing_time,
                    'quality' => (int) $quality,
                );
                if ($ssim !== null) {
                    $result['ssim'] = round($ssim, 4);
                }

                return $result;
            }

            unlink($temp_webp);
            return array('success' => false, 'error' => 'Failed to replace original file');
        }

        if (file_exists($temp_webp)) {
            unlink($temp_webp);
        }

        return array(
            'success' => false,
            'error' => 'WebP conversion failed: ' . ($output ?: 'Unknown error'),
        );
    }

    private function calculate_optimal_quality($file_path, $mime_type) {
        if (!ITT_WebP_Binary_Finder::find_binary('pnmfile')) {
            return $this->default_quality;
        }

        $temp_pnm = $file_path . '.analysis.pnm';

        if ($mime_type === 'image/jpeg') {
            $jpeg_tool = ITT_WebP_Binary_Finder::find_binary('jpegtopnm');
            if (!$jpeg_tool) {
                return $this->default_quality;
            }
            $convert_cmd = escapeshellarg($jpeg_tool) . ' ' . escapeshellarg($file_path) . ' > ' . escapeshellarg($temp_pnm) . ' 2>/dev/null';
        } elseif ($mime_type === 'image/png') {
            $png_tool = ITT_WebP_Binary_Finder::find_binary('pngtopnm');
            if (!$png_tool) {
                return $this->default_quality;
            }
            $convert_cmd = escapeshellarg($png_tool) . ' ' . escapeshellarg($file_path) . ' > ' . escapeshellarg($temp_pnm) . ' 2>/dev/null';
        } else {
            return $this->default_quality;
        }

        $return_code = 0;
        ITT_WebP_Command_Runner::run($convert_cmd, $return_code);

        if ($return_code !== 0 || !file_exists($temp_pnm)) {
            return $this->default_quality;
        }

        $quality = $this->analyze_image_sampling($temp_pnm);
        unlink($temp_pnm);

        return $quality;
    }

    private function analyze_image_sampling($temp_pnm) {
        $pnmfile = ITT_WebP_Binary_Finder::find_binary('pnmfile');
        if (!$pnmfile) {
            return $this->default_quality;
        }

        $return_code = 0;
        $info = ITT_WebP_Command_Runner::run(escapeshellarg($pnmfile) . ' ' . escapeshellarg($temp_pnm) . ' 2>/dev/null', $return_code);

        if (!$info || !preg_match('/(\d+)\s+by\s+(\d+)/', $info, $matches)) {
            return $this->default_quality;
        }

        $width = (int) $matches[1];
        $height = (int) $matches[2];
        $sample_size = min(120, (int) (min($width, $height) / 6));

        if ($sample_size < 50) {
            $sample_size = min(50, (int) (min($width, $height) / 2));
        }

        $positions = array(
            array('name' => 'center', 'x_ratio' => 0.5, 'y_ratio' => 0.5),
            array('name' => 'top_left', 'x_ratio' => 0.25, 'y_ratio' => 0.25),
            array('name' => 'bottom_right', 'x_ratio' => 0.75, 'y_ratio' => 0.75),
        );

        $all_pixels = array();

        foreach ($positions as $position) {
            $pixels = $this->extract_sample($temp_pnm, $width, $height, $sample_size, $position);
            if ($pixels !== false && !empty($pixels)) {
                $all_pixels = array_merge($all_pixels, $pixels);
            }
        }

        if (empty($all_pixels)) {
            return $this->default_quality;
        }

        return $this->analyze_pixel_values($all_pixels);
    }

    private function extract_sample($temp_pnm, $width, $height, $sample_size, $position) {
        $x_offset = max(0, min($width - $sample_size, (int) ($width * $position['x_ratio'] - $sample_size / 2)));
        $y_offset = max(0, min($height - $sample_size, (int) ($height * $position['y_ratio'] - $sample_size / 2)));
        $actual_width = min($sample_size, $width - $x_offset);
        $actual_height = min($sample_size, $height - $y_offset);

        $pnmcut = ITT_WebP_Binary_Finder::find_binary('pnmcut');
        $pnmtoplain = ITT_WebP_Binary_Finder::find_binary('pnmtoplainpnm');

        if (!$pnmcut || !$pnmtoplain) {
            return false;
        }

        $sample_file = $temp_pnm . '.sample_' . $position['name'];
        $cut_cmd = escapeshellarg($pnmcut) . ' -left ' . $x_offset . ' -top ' . $y_offset
            . ' -width ' . $actual_width . ' -height ' . $actual_height . ' '
            . escapeshellarg($temp_pnm) . ' > ' . escapeshellarg($sample_file) . ' 2>/dev/null';

        $return_code = 0;
        ITT_WebP_Command_Runner::run($cut_cmd, $return_code);

        if ($return_code !== 0 || !file_exists($sample_file)) {
            return false;
        }

        $text_file = $sample_file . '.txt';
        $return_code = 0;
        ITT_WebP_Command_Runner::run(
            escapeshellarg($pnmtoplain) . ' ' . escapeshellarg($sample_file) . ' > ' . escapeshellarg($text_file) . ' 2>/dev/null',
            $return_code
        );

        if (!file_exists($text_file)) {
            unlink($sample_file);
            return false;
        }

        $pixels = $this->parse_text_format_to_pixels($text_file);

        unlink($sample_file);
        unlink($text_file);

        return $pixels;
    }

    private function parse_text_format_to_pixels($text_file) {
        $content = file_get_contents($text_file);

        if ($content === false) {
            return false;
        }

        $lines = explode("\n", trim($content));
        $data_started = false;
        $pixel_values = array();

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') {
                continue;
            }

            if (!$data_started) {
                if (preg_match('/^P[123]$/', $line)) {
                    continue;
                }
                if (preg_match('/^\d+\s+\d+$/', $line)) {
                    continue;
                }
                if (preg_match('/^\d+$/', $line)) {
                    $data_started = true;
                    continue;
                }
            } else {
                foreach (preg_split('/\s+/', $line) as $val) {
                    if (is_numeric($val)) {
                        $pixel_values[] = (int) $val;
                    }
                }
            }
        }

        return $pixel_values;
    }

    private function analyze_pixel_values($pixel_values) {
        $total = count($pixel_values);

        if ($total === 0) {
            return $this->default_quality;
        }

        $dark = 0;
        $bright = 0;
        $variance_sum = 0;
        $mean = array_sum($pixel_values) / $total;

        foreach ($pixel_values as $value) {
            if ($value < 60) {
                $dark++;
            }
            if ($value > 220) {
                $bright++;
            }
            $variance_sum += pow($value - $mean, 2);
        }

        $dark_ratio = $dark / $total;
        $bright_ratio = $bright / $total;
        $variance = $variance_sum / $total;

        if ($dark_ratio > 0.015) {
            return min($this->max_quality, $this->default_quality + 8);
        }

        if ($bright_ratio > 0.025) {
            return max($this->min_quality, $this->default_quality - 12);
        }

        if ($variance > 1200) {
            return max($this->min_quality, $this->default_quality - 8);
        }

        if ($variance < 600) {
            return max($this->min_quality, $this->default_quality - 15);
        }

        return $this->default_quality;
    }
}
