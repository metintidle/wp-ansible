<?php
/**
 * System and PHP memory monitoring for processing mode selection.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ITT_WebP_Memory_Manager {

    /** @var array<string, int> */
    private $thresholds = array(
        'high_memory' => 200 * 1024 * 1024,
        'medium_memory' => 100 * 1024 * 1024,
        'low_memory' => 50 * 1024 * 1024,
        'critical_memory' => 30 * 1024 * 1024,
    );

    /**
     * @return array<string, mixed>
     */
    public function get_memory_status() {
        $status = array(
            'total_system_memory' => 0,
            'available_system_memory' => 0,
            'php_memory_limit' => 0,
            'php_memory_used' => memory_get_usage(true),
            'php_memory_available' => 0,
            'processing_mode' => 'low_memory',
            'effective_available' => 0,
        );

        $php_limit = ini_get('memory_limit');
        $status['php_memory_limit'] = $this->parse_memory_value($php_limit);
        $status['php_memory_available'] = max(0, $status['php_memory_limit'] - $status['php_memory_used']);

        if (file_exists('/proc/meminfo')) {
            $meminfo = file_get_contents('/proc/meminfo');

            if (preg_match('/MemTotal:\s+(\d+)\s+kB/', $meminfo, $matches)) {
                $status['total_system_memory'] = (int) $matches[1] * 1024;
            }

            if (preg_match('/MemAvailable:\s+(\d+)\s+kB/', $meminfo, $matches)) {
                $status['available_system_memory'] = (int) $matches[1] * 1024;
            } elseif (
                preg_match('/MemFree:\s+(\d+)\s+kB/', $meminfo, $free)
                && preg_match('/Cached:\s+(\d+)\s+kB/', $meminfo, $cached)
            ) {
                $status['available_system_memory'] = ((int) $free[1] + (int) $cached[1]) * 1024;
            }
        }

        $available = $status['available_system_memory'] > 0
            ? min($status['php_memory_available'], $status['available_system_memory'])
            : $status['php_memory_available'];

        if ($available >= $this->thresholds['high_memory']) {
            $status['processing_mode'] = 'high_memory';
        } elseif ($available >= $this->thresholds['medium_memory']) {
            $status['processing_mode'] = 'medium_memory';
        } elseif ($available >= $this->thresholds['low_memory']) {
            $status['processing_mode'] = 'low_memory';
        } else {
            $status['processing_mode'] = 'critical_memory';
        }

        $status['effective_available'] = $available;

        return $status;
    }

    private function parse_memory_value($value) {
        $value = trim((string) $value);
        $number = (int) $value;
        $unit = strtoupper(substr($value, -1));

        switch ($unit) {
            case 'G':
                return $number * 1024 * 1024 * 1024;
            case 'M':
                return $number * 1024 * 1024;
            case 'K':
                return $number * 1024;
            default:
                return $number;
        }
    }
}
